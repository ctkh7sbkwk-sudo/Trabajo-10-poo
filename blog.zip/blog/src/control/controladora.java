package control;
import logica.*;
import java.util.List;

public class controladora {
	private Blog blog;
	
	private ControladorBlog(String nombre, String descripcion) {
		blog + new Blog(nombre, descripcion);
	
	}
	
	public void crearPublicacion(String titulo, String descripcion, String autor) {
		blog.crearPublicacion(titulo,  texto, autor);
	}
	
	public void agregarComentario(int codPublicacion, String email, String ip, String texto) {
		blog.agregarComentario(codPublicacion, email, ip, texto);
	}
	
	public List<Publicacion> obtenerPublicaciones
}
