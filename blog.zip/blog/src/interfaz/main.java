package interfaz;

import control.controladora;
import logica.*;

public class main {
	public static void main(String[] args) {
		
		Sistema = new Sistema();
		
		Blog blog = sistema.crearBlog("Mi Blog", "Blog de pruebas");
		
		Publicacion pub = sistema.crearPublicacion(
				blog.getCodigo(),
				"Primer Post",
				"Hola mundo",
				"Jose"
		);
		
		sistema.agregarComentario(
				blog.getCodigo(),
				pub.getCodigo(),
				"correo@test.com",
				"192.168.0.1",
				"Buen post!"
		);
		
		for (Publicacion p : blog.getPublicaciones()) {
			System.out.println("Publicación: " + c.getTitulo());
			
			for(Comentario c : p.getComentaros()) {
				System.out.prinltn(" - Comentario: " + c.getTexto());
			}
		}
	}
}
