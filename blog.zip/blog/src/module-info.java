/**
 * 
 */
/**
 * 
 */
module blog {
}